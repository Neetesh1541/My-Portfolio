"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

const skills = [
  { name: "HTML", color: "from-orange-400 to-red-500" },
  { name: "CSS", color: "from-blue-400 to-blue-600" },
  { name: "JavaScript", color: "from-yellow-400 to-yellow-600" },
  { name: "TypeScript", color: "from-blue-500 to-blue-700" },
  { name: "Python", color: "from-green-400 to-blue-500" },
  { name: "C", color: "from-gray-400 to-gray-600" },
  { name: "Django", color: "from-green-600 to-green-800" },
  { name: "Flask", color: "from-gray-500 to-gray-700" },
  { name: "Git", color: "from-orange-500 to-red-600" },
  { name: "GitHub", color: "from-gray-600 to-gray-800" },
  { name: "Basic Java", color: "from-red-500 to-orange-600" },
  { name: "Communication Skills", color: "from-purple-400 to-pink-500" },
]

export default function SkillsSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  return (
    <section id="skills" className="py-20 bg-black">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-8">Skills & Technologies</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A diverse toolkit of technologies and skills that I use to bring ideas to life
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{
                scale: 1.1,
                boxShadow: "0 20px 40px rgba(59, 130, 246, 0.3)",
                y: -10,
              }}
              className={`relative group cursor-pointer`}
            >
              <div className={`bg-gradient-to-r ${skill.color} p-[2px] rounded-2xl`}>
                <div className="bg-black rounded-2xl p-6 h-full flex items-center justify-center">
                  <span className="text-white font-semibold text-center text-sm md:text-base">{skill.name}</span>
                </div>
              </div>

              {/* Glow effect */}
              <motion.div
                className={`absolute inset-0 bg-gradient-to-r ${skill.color} rounded-2xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300`}
                initial={{ scale: 0.8 }}
                whileHover={{ scale: 1.2 }}
              />
            </motion.div>
          ))}
        </div>

        {/* Floating particles */}
        <div className="relative mt-20">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-blue-400 rounded-full opacity-30"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [0, -20, 0],
                opacity: [0.3, 0.8, 0.3],
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Number.POSITIVE_INFINITY,
                delay: Math.random() * 2,
              }}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
