"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type Theme = "neon-dark" | "pastel-light" | "cyber-terminal"

interface ThemeContextType {
  theme: Theme
  setTheme: (theme: Theme) => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>("neon-dark")

  useEffect(() => {
    const root = document.documentElement

    // Remove all theme classes
    root.classList.remove("neon-dark", "pastel-light", "cyber-terminal")

    // Add current theme class
    root.classList.add(theme)

    // Apply theme-specific CSS variables
    switch (theme) {
      case "neon-dark":
        root.style.setProperty("--theme-primary", "#3b82f6")
        root.style.setProperty("--theme-secondary", "#8b5cf6")
        root.style.setProperty("--theme-accent", "#06b6d4")
        root.style.setProperty("--theme-background", "#000000")
        root.style.setProperty("--theme-surface", "#111111")
        root.style.setProperty("--theme-text", "#ffffff")
        root.style.setProperty("--theme-text-secondary", "#94a3b8")
        break
      case "pastel-light":
        root.style.setProperty("--theme-primary", "#f472b6")
        root.style.setProperty("--theme-secondary", "#a78bfa")
        root.style.setProperty("--theme-accent", "#60a5fa")
        root.style.setProperty("--theme-background", "#fef7ff")
        root.style.setProperty("--theme-surface", "#ffffff")
        root.style.setProperty("--theme-text", "#1f2937")
        root.style.setProperty("--theme-text-secondary", "#6b7280")
        break
      case "cyber-terminal":
        root.style.setProperty("--theme-primary", "#22c55e")
        root.style.setProperty("--theme-secondary", "#16a34a")
        root.style.setProperty("--theme-accent", "#84cc16")
        root.style.setProperty("--theme-background", "#000000")
        root.style.setProperty("--theme-surface", "#0a0a0a")
        root.style.setProperty("--theme-text", "#00ff00")
        root.style.setProperty("--theme-text-secondary", "#22c55e")
        break
    }
  }, [theme])

  return <ThemeContext.Provider value={{ theme, setTheme }}>{children}</ThemeContext.Provider>
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider")
  }
  return context
}
