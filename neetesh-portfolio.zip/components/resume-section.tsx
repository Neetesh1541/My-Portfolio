"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import { Download, User, GraduationCap, Code, Mail, Phone, MapPin } from "lucide-react"

export default function ResumeSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  const downloadResume = () => {
    // Create a simple resume content
    const resumeContent = `
NEETESH SHARMA
Full-Stack Developer & CS Engineering Student

CONTACT INFORMATION
Email: neeteshk1104@gmail.com
Phone: +91 8218828273
GitHub: https://github.com/Neetesh1541
LinkedIn: https://www.linkedin.com/in/neetesh-kumar-846616287

EDUCATION
Dr. A.P.J. Abdul Kalam Technical University
Bachelor of Technology in Computer Science Engineering
2023 - 2027 (Expected)

SKILLS
Programming Languages: HTML, CSS, JavaScript, TypeScript, Python, C, Basic Java
Frameworks & Tools: Django, Flask, Git, GitHub
Soft Skills: Communication Skills, Problem Solving, Team Collaboration

PROJECTS
1. Body Dance Clone - Fitness studio website with responsive design
2. FakeFact - AI-based cyber safety and scam detection system
3. Snake Game - Classic game remake with modern UI
4. Net.ai - AI-powered network tool
5. Spotify Clone - Music streaming frontend
6. BhedChaal - AI crowd detection and anomaly system

INTERESTS
Web Development, Artificial Intelligence, Open Source Contribution, Problem Solving
    `

    const blob = new Blob([resumeContent], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "Neetesh_Sharma_Resume.txt"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <section id="resume" className="py-20 bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-8">Resume</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Download my resume or view my qualifications and experience
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Resume Preview */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8"
          >
            <div className="space-y-8">
              {/* Header */}
              <div className="text-center border-b border-gray-700 pb-6">
                <h3 className="text-3xl font-bold text-white mb-2">Neetesh Sharma</h3>
                <p className="text-blue-400 text-lg">Full-Stack Developer & CS Engineering Student</p>
              </div>

              {/* Contact Info */}
              <div className="space-y-3">
                <h4 className="text-xl font-semibold text-white flex items-center">
                  <User className="mr-2" size={20} />
                  Contact Information
                </h4>
                <div className="space-y-2 text-gray-300">
                  <div className="flex items-center">
                    <Mail className="mr-2" size={16} />
                    <span>neeteshk1104@gmail.com</span>
                  </div>
                  <div className="flex items-center">
                    <Phone className="mr-2" size={16} />
                    <span>+91 8218828273</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="mr-2" size={16} />
                    <span>India</span>
                  </div>
                </div>
              </div>

              {/* Education */}
              <div className="space-y-3">
                <h4 className="text-xl font-semibold text-white flex items-center">
                  <GraduationCap className="mr-2" size={20} />
                  Education
                </h4>
                <div className="text-gray-300">
                  <p className="font-semibold">Dr. A.P.J. Abdul Kalam Technical University</p>
                  <p>Bachelor of Technology in Computer Science Engineering</p>
                  <p className="text-blue-400">2023 - 2027 (Expected)</p>
                </div>
              </div>

              {/* Skills */}
              <div className="space-y-3">
                <h4 className="text-xl font-semibold text-white flex items-center">
                  <Code className="mr-2" size={20} />
                  Key Skills
                </h4>
                <div className="flex flex-wrap gap-2">
                  {["JavaScript", "Python", "Django", "Flask", "HTML/CSS", "Git"].map((skill) => (
                    <span
                      key={skill}
                      className="text-xs text-blue-300 bg-blue-900/30 px-3 py-1 rounded-full border border-blue-500/30"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Download Section */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col justify-center space-y-8"
          >
            <div className="text-center">
              <h3 className="text-3xl font-bold text-white mb-4">Get My Full Resume</h3>
              <p className="text-gray-300 text-lg mb-8">
                Download my complete resume with detailed information about my projects, experience, and technical
                skills.
              </p>

              <motion.button
                onClick={downloadResume}
                className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
                whileHover={{
                  scale: 1.05,
                  boxShadow: "0 20px 40px rgba(59, 130, 246, 0.3)",
                }}
                whileTap={{ scale: 0.95 }}
              >
                <Download className="mr-2" size={20} />
                Download Resume
              </motion.button>
            </div>

            <div className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 backdrop-blur-sm border border-blue-500/20 rounded-2xl p-6">
              <h4 className="text-xl font-bold text-white mb-4">Why Hire Me?</h4>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-start">
                  <span className="text-blue-400 mr-2">•</span>
                  Passionate about creating innovative solutions
                </li>
                <li className="flex items-start">
                  <span className="text-blue-400 mr-2">•</span>
                  Strong foundation in both frontend and backend development
                </li>
                <li className="flex items-start">
                  <span className="text-blue-400 mr-2">•</span>
                  Experience with AI/ML and modern web technologies
                </li>
                <li className="flex items-start">
                  <span className="text-blue-400 mr-2">•</span>
                  Excellent communication and problem-solving skills
                </li>
                <li className="flex items-start">
                  <span className="text-blue-400 mr-2">•</span>
                  Always eager to learn and adapt to new technologies
                </li>
              </ul>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
