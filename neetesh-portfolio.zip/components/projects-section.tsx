"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef, useState } from "react"
import { ExternalLink, Github, ChevronLeft, ChevronRight } from "lucide-react"

const projects = [
  {
    title: "Body Dance Clone",
    description:
      "A modern fitness studio website with responsive design and interactive features. Built with clean HTML, CSS, and JavaScript for optimal performance.",
    image: "/images/body-dance.png",
    tech: ["HTML", "CSS", "JavaScript"],
    github: "https://github.com/Neetesh1541",
    live: "#",
    category: "Web Development",
  },
  {
    title: "FakeFact",
    description:
      "AI-based cyber safety and scam detection system to protect users from online threats. Uses machine learning algorithms to identify fake news and scams.",
    image: "/images/fakefact-ai.png",
    tech: ["Python", "AI/ML", "Flask"],
    github: "https://github.com/Neetesh1541",
    live: "#",
    category: "AI/ML",
  },
  {
    title: "Snake Game",
    description:
      "Classic snake game remake with modern UI and smooth gameplay mechanics. Features responsive controls and progressive difficulty levels.",
    image: "/images/snake-game.png",
    tech: ["JavaScript", "HTML5 Canvas", "CSS"],
    github: "https://github.com/Neetesh1541",
    live: "#",
    category: "Game Development",
  },
  {
    title: "Net.ai",
    description:
      "AI-powered network tool for intelligent network analysis and optimization. Provides real-time monitoring and automated network management.",
    image: "/images/net-ai.png",
    tech: ["Python", "AI", "Networking"],
    github: "https://github.com/Neetesh1541",
    live: "#",
    category: "AI/ML",
  },
  {
    title: "Spotify Clone",
    description:
      "Music streaming frontend with modern UI and responsive design. Replicates Spotify's interface with custom styling and interactive elements.",
    image: "/images/spotify-clone.png",
    tech: ["HTML", "CSS", "JavaScript"],
    github: "https://github.com/Neetesh1541",
    live: "#",
    category: "Web Development",
  },
  {
    title: "BhedChaal",
    description:
      "AI crowd detection and anomaly system for smart surveillance and safety. Uses computer vision to monitor crowd density and detect unusual patterns.",
    image: "/images/bhedchaal-ai.png",
    tech: ["Python", "Computer Vision", "AI"],
    github: "https://github.com/Neetesh1541",
    live: "#",
    category: "AI/ML",
  },
]

export default function ProjectsSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextProject = () => {
    setCurrentIndex((prev) => (prev + 1) % projects.length)
  }

  const prevProject = () => {
    setCurrentIndex((prev) => (prev - 1 + projects.length) % projects.length)
  }

  const openGitHub = () => {
    window.open("https://github.com/Neetesh1541", "_blank")
  }

  return (
    <section id="projects" className="py-20 bg-gradient-to-b from-black to-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-8">Featured Projects</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">A showcase of my latest work and creative solutions</p>
        </motion.div>

        {/* Desktop Grid View */}
        <div className="hidden lg:grid lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="group relative cursor-pointer"
              onClick={openGitHub}
            >
              <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl overflow-hidden hover:border-blue-500/50 transition-all duration-300">
                <div className="relative overflow-hidden">
                  <img
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                  {/* GitHub overlay on hover */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="bg-black/80 backdrop-blur-sm rounded-full p-4">
                      <Github className="text-white" size={32} />
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold text-blue-400 bg-blue-400/10 px-3 py-1 rounded-full">
                      {project.category}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-blue-400 transition-colors">
                    {project.title}
                  </h3>

                  <p className="text-gray-300 text-sm mb-4 line-clamp-3">{project.description}</p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tech.map((tech) => (
                      <span key={tech} className="text-xs text-gray-300 bg-gray-700/50 px-2 py-1 rounded-md">
                        {tech}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-gray-400">
                      <Github size={16} />
                      <span className="text-sm">Click to view on GitHub</span>
                    </div>
                    <ExternalLink className="text-blue-400" size={16} />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Mobile Carousel View */}
        <div className="lg:hidden">
          <div className="relative">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.3 }}
              className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl overflow-hidden cursor-pointer"
              onClick={openGitHub}
            >
              <div className="relative overflow-hidden">
                <img
                  src={projects[currentIndex].image || "/placeholder.svg"}
                  alt={projects[currentIndex].title}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-sm rounded-full p-2">
                  <Github className="text-white" size={20} />
                </div>
              </div>

              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-blue-400 bg-blue-400/10 px-3 py-1 rounded-full">
                    {projects[currentIndex].category}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-white mb-3">{projects[currentIndex].title}</h3>

                <p className="text-gray-300 text-sm mb-4">{projects[currentIndex].description}</p>

                <div className="flex flex-wrap gap-2 mb-4">
                  {projects[currentIndex].tech.map((tech) => (
                    <span key={tech} className="text-xs text-gray-300 bg-gray-700/50 px-2 py-1 rounded-md">
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-gray-400">
                    <Github size={16} />
                    <span className="text-sm">Tap to view on GitHub</span>
                  </div>
                  <ExternalLink className="text-blue-400" size={16} />
                </div>
              </div>
            </motion.div>

            {/* Navigation buttons */}
            <button
              onClick={(e) => {
                e.stopPropagation()
                prevProject()
              }}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors z-10"
            >
              <ChevronLeft size={20} />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation()
                nextProject()
              }}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors z-10"
            >
              <ChevronRight size={20} />
            </button>

            {/* Dots indicator */}
            <div className="flex justify-center mt-6 space-x-2">
              {projects.map((_, index) => (
                <button
                  key={index}
                  onClick={(e) => {
                    e.stopPropagation()
                    setCurrentIndex(index)
                  }}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index === currentIndex ? "bg-blue-400" : "bg-gray-600"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-center mt-16"
        >
          <p className="text-gray-300 mb-6">Want to see more of my work?</p>
          <motion.button
            onClick={openGitHub}
            className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
            whileHover={{
              scale: 1.05,
              boxShadow: "0 20px 40px rgba(59, 130, 246, 0.3)",
            }}
            whileTap={{ scale: 0.95 }}
          >
            <Github className="mr-2" size={20} />
            Visit My GitHub Profile
          </motion.button>
        </motion.div>
      </div>
    </section>
  )
}
