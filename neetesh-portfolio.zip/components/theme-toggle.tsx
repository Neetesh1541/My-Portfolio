"use client"

import { motion } from "framer-motion"
import { Palette } from "lucide-react"
import { useState } from "react"
import { useTheme } from "./theme-provider"

const themes = [
  { name: "Neon Dark", value: "neon-dark", color: "from-blue-500 to-purple-600" },
  { name: "Pastel Light", value: "pastel-light", color: "from-pink-300 to-blue-300" },
  { name: "Cyber Terminal", value: "cyber-terminal", color: "from-green-400 to-green-600" },
]

export default function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="fixed top-20 right-4 z-40">
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="p-3 bg-black/20 backdrop-blur-md border border-white/10 rounded-full text-white hover:bg-white/10 transition-all duration-300"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        <Palette size={20} />
      </motion.button>

      {isOpen && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: -10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: -10 }}
          className="absolute top-16 right-0 bg-black/80 backdrop-blur-md border border-white/10 rounded-lg p-4 min-w-48"
        >
          <h3 className="text-white font-semibold mb-3">Choose Theme</h3>
          <div className="space-y-2">
            {themes.map((themeOption) => (
              <motion.button
                key={themeOption.value}
                onClick={() => {
                  setTheme(themeOption.value as any)
                  setIsOpen(false)
                }}
                className={`w-full flex items-center space-x-3 p-2 rounded-lg transition-all duration-300 ${
                  theme === themeOption.value ? "bg-white/20 border border-white/30" : "hover:bg-white/10"
                }`}
                whileHover={{ x: 5 }}
              >
                <div className={`w-4 h-4 rounded-full bg-gradient-to-r ${themeOption.color}`} />
                <span className="text-white text-sm">{themeOption.name}</span>
              </motion.button>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  )
}
